import React, { useState } from 'react';
import { useDashboard } from '../contexts/DashboardContext';
import { getJobMarketAnalysis } from '../services/gemini';
import { TrendingUp, Loader2 } from 'lucide-react';
import Markdown from 'react-markdown';

export const JobMarketPage: React.FC = () => {
  const { profile } = useDashboard();
  const [analysis, setAnalysis] = useState<{ text: string; sources: any[] } | null>(null);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAnalysis = async () => {
    if (!profile || !profile.education) {
      setError("Please complete your profile (Education is required) first.");
      return;
    }
    setGenerating(true);
    setError(null);
    try {
      const res = await getJobMarketAnalysis(profile);
      setAnalysis(res);
    } catch (err: any) {
      console.error("Error fetching job market analysis:", err);
      setError(err.message || "Failed to fetch job market analysis. Please try again.");
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-8 pb-32">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <h2 className="text-3xl font-headline font-extrabold text-primary">Job Market Trends</h2>
          <p className="text-on-surface-variant text-sm">Analyze current trends, relevant roles, and skill gaps in India.</p>
        </div>
        <button onClick={fetchAnalysis} disabled={generating} className="bg-primary text-on-primary px-8 py-4 rounded-full font-label font-bold text-sm shadow-lg hover:opacity-90 transition-all flex items-center gap-2 whitespace-nowrap">
          {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />}
          Analyze Market
        </button>
      </div>

      {error && (
        <div className="bg-error/10 text-error p-4 rounded-xl font-label text-sm">
          {error}
        </div>
      )}
      
      {analysis && (
        <div className="bg-surface-container-lowest p-8 rounded-[2.5rem] border border-outline-variant/20 shadow-editorial space-y-8">
          <div className="markdown-body text-on-surface-variant leading-relaxed">
            <Markdown>{analysis.text}</Markdown>
          </div>
          {analysis.sources && analysis.sources.length > 0 && (
            <div className="pt-6 border-t border-outline-variant/20">
              <h4 className="font-label font-bold text-sm text-on-surface uppercase tracking-wider mb-4">Reference Links</h4>
              <ul className="space-y-2">
                {analysis.sources.map((source: any, idx: number) => {
                  const url = source?.web?.uri;
                  const title = source?.web?.title;
                  if (!url) return null;
                  return (
                    <li key={idx}>
                      <a href={url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline text-sm font-medium flex items-center gap-2">
                        {title || url}
                      </a>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
